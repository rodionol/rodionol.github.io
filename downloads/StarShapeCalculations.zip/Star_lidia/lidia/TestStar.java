/*******************************************************************************
 * TestLine.java
 * 
 * This file is part of Assignment 6 for PROG10082.
 * This is a test for the Star.java class, tesing the intersect() and 
 * isIntersected() methods.
 *
 * AUTHOR: Lidia Rodionova (rodionol@sheridancollege.ca)
 * CREATED: 2017-04-15
 * UPDATED: 2017-04-15
 *******************************************************************************/
package lidia;

import lidia.Vector2;
import lidia.Line;
import lidia.Star;

public class TestStar
{
    public static void main(String[] args)
    {
        // define a default star
        Star ds = new Star(5, 10);
        for (int i = 0; i < ds.vertices.length; i++){
            //System.out.println(ds.angle);
            //System.out.println(ds.D2R);
            System.out.println(i + ": " + ds.vertices[i]);
        }
        
        // array of stars
        Star[] astar = new Star[10];
        astar[0] = new Star();
        
        //astar[0].vertices[0] = new Vector2(0.0f, 10.0f);
        //astar[0].vertices[0].y = 10.0f;
        
        System.out.println(astar[0].angle);
        System.out.println(astar[0].vertices[0]);
        
        
    }
}
