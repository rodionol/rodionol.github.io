/*******************************************************************************
 * TestLine.java
 * 
 * This file is part of Assignment 6 for PROG10082.
 * This is a test for the Line.java class, tesing the intersect() and 
 * isIntersected() methods.
 *
 * AUTHOR: Lidia Rodionova (rodionol@sheridancollege.ca)
 * CREATED: 2017-04-11
 * UPDATED: 2017-04-15
 *******************************************************************************/
package lidia;

import lidia.Vector2;
import lidia.Line;

public class TestLine
{
    public static void main(String[] args)
    {
        // define a line with 2 end-points
        Line line1 = new Line(1, 2, 10, 20);
        Line line2 = new Line(0, 15, 10, 5);
        
        // print lines
        System.out.println(line1);
        System.out.println(line2);
        
        // check if they are intersected
        boolean intersected = line1.isIntersected(line2);
        if(intersected)
        {
            Vector2 point = line1.intersect(line2);
            System.out.println("Point of Intersection: (" +  point.x + ", " + point.y + ")");
        }
        else
        {
            System.out.println("Not Intersected");
        }
    }
}
