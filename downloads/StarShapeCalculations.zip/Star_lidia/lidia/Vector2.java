/*******************************************************************************
 * Vector2.java
 * 
 * This file is part of Assignment 6 for PROG10082.
 * It defines a single point on a cartesian plane (x and y coordinates).
 * This class will be used to build a line class consisting of two points 
 * joined into a line.
 *
 * AUTHOR: Lidia Rodionova (rodionol@sheridancollege.ca)
 * CREATED: 2017-04-08
 * UPDATED: 2017-04-15
 *******************************************************************************/
package lidia;

public class Vector2 {

    /********************************************************************************
    * define instance vars **********************************************************/
    public float x;
    public float y;
    
    /********************************************************************************
    * constructor(s)  ***************************************************************/
    public Vector2(){
        set(0, 0);
    }
    public Vector2(float x, float y){
        set(x, y);
    }
    
     /********************************************************************************
    /* methods ***********************************************************************/   
    public void set(float x, float y){
        this.x = x;
        this.y = y;
    }
    
    public void set(Vector2 v){
        set(v.x, v.y);
    }
    
    // override toString()
    @Override
    public String toString(){        
        return "Vector2(" + this.x + ", " + this.y + ")";
    }
    
    public Vector2 clone(){
        return new Vector2(this.x, this.y);        
    }
    
    public Vector2 add(Vector2 rhs){
        this.x += rhs.x;
        this.y += rhs.y;
        return this;
    }
    
    public Vector2 subtract(Vector2 rhs){
        this.x -= rhs.x;
        this.y -= rhs.y;
        return this;
    }
    
    public Vector2 scale(float scalar){
        this.x *= scalar;
        this.y *= scalar;
        return this;
    }
    
    public float dot(Vector2 rhs){
        return (this.x * rhs.x + this.y * rhs.y);
    }
    
    public float getLength(){
        return (float)Math.sqrt(this.x * this.x + this.y * this.y);
    }
    
    public Vector2 normalize(){
        float d = getLength();
        x /= d;
        y /= d;
        return this;
    }
    
}