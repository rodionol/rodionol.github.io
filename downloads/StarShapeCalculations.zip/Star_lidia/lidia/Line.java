/*******************************************************************************
 * Line.java
 * 
 * This file is part of Assignment 6 for PROG10082.
 * It defines a line using two points (using Vector2 class in same package) 
 * on a cartesian plane. This class can be used to draw elements in the 
 * using the OpenGL (JOGL) library.
 *
 * AUTHOR: Lidia Rodionova (rodionol@sheridancollege.ca)
 * CREATED: 2017-04-11
 * UPDATED: 2017-04-15
 *******************************************************************************/
package lidia;

public class Line {
    /********************************************************************************
    *** define instance vars ********************************************************/
    
    private Vector2 point;
    private Vector2 direction;
    
    /********************************************************************************
    *** constructor(s) **************************************************************/

    public Line(){
        point.x = 0.0f;
        point.y = 0.0f;
        direction.x = 1.0f;
        direction.y = 1.0f;
    }
    
    public Line(Vector2 point, Vector2 direction){
        this.point = point;
        this.direction = direction;
    }
    
    public Line(float slope, float intercept){
        point.x = 0;
        point.y = intercept;
        direction.x = 1;
        direction.y = intercept + slope;
    }
    
    public Line(float x1, float y1, float x2, float y2){
        Vector2 v1 = new Vector2(x1, y1);
        Vector2 v2 = new Vector2(x2, y2);
        this.point = v1;
        this.direction = v2;
    }
    
    /********************************************************************************
    *** method(s) *******************************************************************/   
    
    public void set(Vector2 point, Vector2 direction){
        this.point = point;
        this.direction = direction;
    }
    
    public void set(float slope, float intercept){
        this.point.x = 0;
        this.point.y = intercept;
        this.direction.x = 1;
        this.direction.y = intercept + slope;
    }
    
    public void set(float x1, float y1, float x2, float y2){
        this.point.x = x1;
        this.point.y = y1;
        this.direction.x = x2;
        this.direction.y = y2;
    }
    
    public void setPoint(Vector2 point){
        this.point = point;
    }
    
    public Vector2 getPoint(){
        return this.point;
    }
    
    public void setDirection(Vector2 direction){
        this.direction = direction;
    }
    
    public Vector2 getDirection(){
        return this.direction;
    }
    
    @Override
    public String toString(){
        String lineParameters = "Line\n" + "====\n" + "Point: (" + this.point.x + ", " + this.point.y + ")\n" + "Direction: (" + this.direction.x + ", " + this.direction.y + ")";
        return lineParameters;
    }
    
    public Vector2 intersect(Line line){
        
        Vector2 intersectPoint = new Vector2();
        
        if (this.isIntersected(line)){
            // define vars for standard equation to make things less confusing
            float c = (this.direction.y - this.point.y)*this.point.x - (this.direction.x - this.point.x)*this.point.y; 
            float a = direction.y - point.y;
            float b = point.x - direction.x;
            
            // line 2
            float f = (line.direction.y - line.point.y)*line.point.x - (line.direction.x - line.point.x)*line.point.y; ;
            float d = line.direction.y - line.point.y;
            float e = line.point.x - line.direction.x;
            
            intersectPoint.x = (c*e - b*f) / (a*e - b*d);
            intersectPoint.y = (a*f - c*d) / (a*e - b*d);
                        
        } else {
            
            intersectPoint.x = Float.NaN;
            intersectPoint.y = Float.NaN;
        }
        return intersectPoint;
        
    }
    
    public boolean isIntersected(Line line){
        
        // define vars for standard equation
        // line 1
        float c = (this.direction.y - this.point.y)*this.point.x - (this.direction.x - this.point.x)*this.point.y; 
        float a = this.direction.y - this.point.y;
        float b = this.direction.x - this.point.x;
                
        // line2
        float f = (line.direction.y - line.point.y)*line.point.x - (line.direction.x - line.point.x)*line.point.y; ;
        float d = line.direction.y - line.point.y;
        float e = line.direction.x - line.point.x;
        
        if ((a*e - b*d) == 0){
            return false;
        } else {
            return true;
        }
    }
    
    
    
}