/*******************************************************************************
 * Star.java
 * 
 * This file is part of Assignment 6 for PROG10082.
 * It defines a line using two points (using Vector2 class in same package) 
 * on a cartesian plane. This class can be used to draw elements in the 
 * using the OpenGL (JOGL) library.
 *
 * AUTHOR: Lidia Rodionova (rodionol@sheridancollege.ca)
 * CREATED: 2017-04-15
 * UPDATED: 2017-04-15
 *******************************************************************************/
package lidia;

public class Star {
    
    final public double D2R = Math.PI / 180;
    
    /********************************************************************************
    *** define instance vars ********************************************************/
    
    public int numOfPoints = 5; // default num of points is 5
    public Vector2[] vertices = new Vector2[numOfPoints*2]; 
    public float angle = 72; // angle in degrees
    
    /********************************************************************************
    *** constructor(s) **************************************************************/
    
    // default star has 5 points and a radius of 10
    public Star(){

        vertices[0] = new Vector2(0.0f, 10.0f);
        
        // calculate outer points
        double D2R = Math.PI / 180;
        float defaultAngle = 72; // angle in degrees
               
        // Outer Points 
        for (int i = 2; i < 10; i+=2) {
             
            // determine angle for calculations
            if (i == 2) {
                angle = defaultAngle;
            } else {
                angle = angle + 72;
            }
                        
            float x = 10 * (float)Math.sin(D2R * angle);
            float y = 10 * (float)Math.cos(D2R * angle);
            Vector2 point = new Vector2(x, y);
            vertices[i] = point;
            
        }
                          
        // inner points    
        Line l1 = new Line(vertices[0].x, vertices[0].y, vertices[4].x, vertices[4].y); // p0 to p4
        Line l2 = new Line(vertices[2].x, vertices[2].y, vertices[8].x, vertices[8].y); // p2 to p8
        vertices[1] = l1.intersect(l2);
  
        Line l3 = new Line(vertices[2].x, vertices[2].y, vertices[6].x, vertices[6].y); // p2 to p6
        vertices[3] = l1.intersect(l3);
        
        Line l4 = new Line(vertices[4].x, vertices[4].y, vertices[8].x, vertices[8].y); // p4 to p8
        vertices[5] = l3.intersect(l4);
      
        Line l5 = new Line(vertices[0].x, vertices[0].y, vertices[6].x, vertices[6].y); // p0 to p6
        vertices[7] = l4.intersect(l5);
      
        vertices[9] = l2.intersect(l5);
        
    }
    
    // 5 point star with set radius
    public Star(float radius){
            
        // top point
        //Vector2 point0 = new Vector2(0.0f, radius);
        vertices[0] = new Vector2(0.0f, radius);; 

        // calculate outer points
        double D2R = Math.PI / 180;
        float defaultAngle = 360 / 5; // angle in degrees
               
        // Outer Points 
        for (int i = 2; i < vertices.length; i+=2) {
             
            // determine angle for calculations
            if (i == 2) {
                angle = defaultAngle;
            } else {
                angle = angle + defaultAngle;
            }
                        
            float x = radius * (float)Math.sin(D2R * angle);
            float y = radius * (float)Math.cos(D2R * angle);
            Vector2 point = new Vector2(x, y);
            vertices[i] = point;
            
        }
                          
        // inner points  
        
        Line l1 = new Line(vertices[0].x, vertices[0].y, vertices[4].x, vertices[4].y); // p0 to p4
        Line l2 = new Line(vertices[2].x, vertices[2].y, vertices[8].x, vertices[8].y); // p2 to p8
        vertices[1] = l1.intersect(l2);
  
        Line l3 = new Line(vertices[2].x, vertices[2].y, vertices[6].x, vertices[6].y); // p2 to p6
        vertices[3] = l1.intersect(l3);
        
        Line l4 = new Line(vertices[4].x, vertices[4].y, vertices[8].x, vertices[8].y); // p4 to p8
        vertices[5] = l3.intersect(l4);
      
        Line l5 = new Line(vertices[0].x, vertices[0].y, vertices[6].x, vertices[6].y); // p0 to p6
        vertices[7] = l4.intersect(l5);
      
        vertices[9] = l2.intersect(l5);
        
    }
        
    // set number of points & radius
    public Star(int points, float radius){
            
        // top point
        vertices[0] = new Vector2(0.0f, radius);

        // calculate outer points
        double D2R = Math.PI / 180;
        float defaultAngle = 360 / points; // angle in degrees
               
        // Outer Points 
        for (int i = 2; i < vertices.length; i+=2) {
             
            // determine angle for calculations
            if (i == 2) {
                angle = defaultAngle;
            } else {
                angle = angle + defaultAngle;
            }
                        
            float x = radius * (float)Math.sin(D2R * angle);
            float y = radius * (float)Math.cos(D2R * angle);
            Vector2 point = new Vector2(x, y);
            vertices[i] = point;
            
        }
                          
        // Inner points  
        defaultAngle = 360 / points / 2; // angle in degrees
        for (int i = 1; i < vertices.length; i +=2){
            if (i == 1){
                angle = defaultAngle / 2;
            } else {
                angle = angle + angle*2;
            }
            
            float x = (radius/2) * (float)Math.sin(D2R * (angle/2));
            float y = (radius/2) * (float)Math.cos(D2R * (angle/2));
            Vector2 point = new Vector2(x, y);
            vertices[i] = point;
            
        }
        
//        Line l1 = new Line(vertices[0].x, vertices[0].y, vertices[4].x, vertices[4].y); // p0 to p4
//        Line l2 = new Line(vertices[2].x, vertices[2].y, vertices[8].x, vertices[8].y); // p2 to p8
//        vertices[1] = l1.intersect(l2);
//  
//        Line l3 = new Line(vertices[2].x, vertices[2].y, vertices[6].x, vertices[6].y); // p2 to p6
//        vertices[3] = l1.intersect(l3);
//        
//        Line l4 = new Line(vertices[4].x, vertices[4].y, vertices[8].x, vertices[8].y); // p4 to p8
//        vertices[5] = l3.intersect(l4);
//      
//        Line l5 = new Line(vertices[0].x, vertices[0].y, vertices[6].x, vertices[6].y); // p0 to p6
//        vertices[7] = l4.intersect(l5);
//      
//        vertices[9] = l2.intersect(l5);
        
    }
    
    
    /********************************************************************************
    *** method(s) *******************************************************************/   
    public void setNumPoints(int points){
        this.numOfPoints = points;
    }
    
}